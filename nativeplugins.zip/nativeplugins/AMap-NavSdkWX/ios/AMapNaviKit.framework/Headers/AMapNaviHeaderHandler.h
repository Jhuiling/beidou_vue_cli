//
//  AMapNaviHeaderHandler.h
//  AMapNaviKit
//
//  Created by eidan on 2018/9/21.
//  Copyright © 2018年 Amap. All rights reserved.
//

#define AMapNaviKit_Dynamic_Lib 0 

#if AMapNaviKit_Dynamic_Lib
#import <AMapNaviKit/MAMapKit.h>
#else
#import <MAMapKit/MAMapKit.h>
#endif
